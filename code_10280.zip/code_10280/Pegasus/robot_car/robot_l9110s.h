
#ifndef __ROBOT_L9110S_H__
#define __ROBOT_L9110S_H__

void car_backward(void);
void car_forward(void);
void car_left(void);
void car_right(void);
void car_stop(void);
#endif
