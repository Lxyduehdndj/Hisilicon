
#ifndef __TRACE_MODEL_H__
#define __TRACE_MODEL_H__

void trace_module(void);
#endif